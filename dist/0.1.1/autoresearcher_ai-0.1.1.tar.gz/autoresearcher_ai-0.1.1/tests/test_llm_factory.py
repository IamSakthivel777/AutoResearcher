from __future__ import annotations

import pytest

from autoresearcher.config import Settings
from autoresearcher.errors import ConfigurationError, MissingAPIKeyError
from autoresearcher.llm.factory import get_llm, resolve_route


def test_requested_provider_falls_back_and_warns(monkeypatch, tmp_path) -> None:
    monkeypatch.chdir(tmp_path)
    settings = Settings(openai_api_key="secret", models={"planner": "claude"})
    warnings: list[str] = []
    received: dict[str, object] = {}

    def builder(**kwargs: object) -> object:
        received.update(kwargs)
        return object()

    model = get_llm("planner", settings, warnings=warnings, builders={"openai": builder})

    assert model is not None
    assert received["model"] == "gpt-5"
    assert received["api_key"] == "secret"
    assert received["timeout"] == 180
    assert warnings == [
        "The requested anthropic provider for planner is not configured; using openai instead."
    ]


def test_llm_timeout_is_independent_from_tool_timeout(monkeypatch, tmp_path) -> None:
    monkeypatch.chdir(tmp_path)
    settings = Settings(
        openai_api_key="secret",
        task_timeout_seconds=30,
        llm_timeout_seconds=240,
    )
    received: dict[str, object] = {}

    def builder(**kwargs: object) -> object:
        received.update(kwargs)
        return object()

    get_llm("planner", settings, builders={"openai": builder})

    assert received["timeout"] == 240
    assert settings.task_timeout_seconds == 30


def test_explicit_model_id_is_preserved(monkeypatch, tmp_path) -> None:
    monkeypatch.chdir(tmp_path)
    settings = Settings(
        gemini_api_key="secret",
        models={"worker": "gemini:gemini-custom"},
    )

    route = resolve_route("worker", settings)

    assert route.provider == "gemini"
    assert route.model == "gemini-custom"


def test_missing_all_llm_keys_is_actionable(monkeypatch, tmp_path) -> None:
    monkeypatch.chdir(tmp_path)
    for name in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY"):
        monkeypatch.delenv(name, raising=False)

    with pytest.raises(MissingAPIKeyError, match="ANTHROPIC_API_KEY"):
        resolve_route("planner", Settings())


def test_unknown_provider_is_rejected(monkeypatch, tmp_path) -> None:
    monkeypatch.chdir(tmp_path)
    settings = Settings(openai_api_key="secret", models={"planner": "unknown"})

    with pytest.raises(ConfigurationError, match="Unknown model provider"):
        resolve_route("planner", settings)
