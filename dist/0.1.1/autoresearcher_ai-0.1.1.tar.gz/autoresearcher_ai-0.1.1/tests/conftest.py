from __future__ import annotations

from typing import Any

import pytest

from autoresearcher.models import ResearchPlan, Task


class FakeStructuredModel:
    def __init__(self, value: Any) -> None:
        self.value = value
        self.calls = 0

    async def ainvoke(self, prompt: str) -> Any:
        self.calls += 1
        assert "User question:" in prompt
        if isinstance(self.value, list):
            return self.value[min(self.calls - 1, len(self.value) - 1)]
        return self.value


class FakePlanner:
    def __init__(self, value: Any) -> None:
        self.structured = FakeStructuredModel(value)

    def with_structured_output(self, schema: type[Any]) -> FakeStructuredModel:
        assert schema is ResearchPlan
        return self.structured


@pytest.fixture
def research_plan() -> ResearchPlan:
    return ResearchPlan(
        goal="Chennai: a three-day research brief",
        assumptions=["The traveler has three full days."],
        template="trip",
        todo_list=["Find major sights", "Find practical travel advice"],
        tasks=[
            Task(
                id="sights",
                title="Major sights",
                worker_type="web",
                query="Chennai major sights official tourism",
                priority=5,
            ),
            Task(
                id="practical",
                title="Practical advice",
                worker_type="web",
                query="Chennai local transport visitor guide",
                priority=4,
            ),
        ],
    )


@pytest.fixture
def fake_planner(research_plan: ResearchPlan) -> FakePlanner:
    return FakePlanner(research_plan)

