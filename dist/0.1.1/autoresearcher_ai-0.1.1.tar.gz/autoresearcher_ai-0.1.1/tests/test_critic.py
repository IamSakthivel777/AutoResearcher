from __future__ import annotations

from autoresearcher.graph.critic import deterministic_critique
from autoresearcher.models import Claim, Finding, ResearchPlan, Source, Task


def test_critic_rejects_claims_with_unknown_source_ids() -> None:
    plan = ResearchPlan(
        goal="Verify evidence",
        todo_list=["Check evidence"],
        tasks=[Task(id="verify", title="Verify", query="verify evidence")],
    )
    finding = Finding(
        task_id="verify",
        claims=[Claim(text="Unsupported mapping", source_ids=["S2"])],
    )
    source = Source(id="S1", url="https://example.com", title="Known source")

    critique = deterministic_critique("Verify evidence", plan, [finding], [source])

    assert critique.verdict == "revise"
    assert critique.uncited_claims == ["Unsupported mapping"]

