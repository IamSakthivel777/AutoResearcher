from __future__ import annotations

from autoresearcher.config import Settings


def test_constructor_overrides_environment_and_dotenv(tmp_path, monkeypatch) -> None:
    env_file = tmp_path / ".env"
    env_file.write_text("OPENAI_API_KEY=from-dotenv\n", encoding="utf-8")
    monkeypatch.setenv("OPENAI_API_KEY", "from-environment")

    settings = Settings.from_env_file(env_file, openai_api_key="from-constructor")

    assert settings.openai_api_key is not None
    assert settings.openai_api_key.get_secret_value() == "from-constructor"


def test_google_key_alias_and_empty_values(tmp_path, monkeypatch) -> None:
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.setenv("GOOGLE_API_KEY", "google-secret")
    settings = Settings.from_env_file(tmp_path / "missing", anthropic_api_key="")

    assert settings.anthropic_api_key is None
    assert settings.gemini_api_key is not None
    assert settings.gemini_api_key.get_secret_value() == "google-secret"


def test_settings_and_researcher_repr_do_not_reveal_keys(monkeypatch, tmp_path) -> None:
    monkeypatch.chdir(tmp_path)
    settings = Settings(openai_api_key="highly-secret")

    assert "highly-secret" not in repr(settings)
    assert "highly-secret" not in str(settings)

