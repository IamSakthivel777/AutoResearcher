from __future__ import annotations

import asyncio

from conftest import FakePlanner

from autoresearcher import AutoResearcher, CriticVerdict
from autoresearcher.models import ResearchPlan, Task
from autoresearcher.tools.search import SearchResponse, SearchResult


async def test_send_workers_run_in_parallel_and_fan_in_once(tmp_path) -> None:
    plan = ResearchPlan(
        goal="Parallel research",
        todo_list=["Research three themes"],
        tasks=[
            Task(id=f"task-{index}", title=f"Theme {index}", query=f"theme-{index}")
            for index in range(3)
        ],
    )
    active = 0
    peak_active = 0

    async def concurrent_search(query: str, **_kwargs: object) -> SearchResponse:
        nonlocal active, peak_active
        active += 1
        peak_active = max(peak_active, active)
        await asyncio.sleep(0.02)
        active -= 1
        return SearchResponse(
            provider="fake",
            results=[
                SearchResult(
                    title=query,
                    url=f"https://example.com/{query}",
                    snippet=f"Evidence for {query}",
                )
            ],
        )

    events = []
    researcher = AutoResearcher(
        _llm=FakePlanner(plan),
        _searcher=concurrent_search,
        max_subagents=2,
    )
    result = await researcher.arun(
        "Research three themes",
        output=tmp_path / "parallel.docx",
        _event_sink=events.append,
    )

    assert peak_active == 2
    assert len(result.sources) == 2
    assert len(result.plan.tasks) == 2
    assert sum(isinstance(event, CriticVerdict) for event in events) == 1


async def test_critic_revision_adds_a_gap_task_then_passes(tmp_path) -> None:
    plan = ResearchPlan(
        goal="Critic loop",
        todo_list=["Find evidence"],
        tasks=[Task(id="original", title="Original task", query="evidence")],
    )
    calls = 0

    async def improving_search(query: str, **_kwargs: object) -> SearchResponse:
        nonlocal calls
        calls += 1
        if calls == 1:
            return SearchResponse(provider="fake", results=[])
        return SearchResponse(
            provider="fake",
            results=[
                SearchResult(
                    title="Recovered source",
                    url="https://example.com/recovered",
                    snippet="Recovered source-backed evidence.",
                )
            ],
        )

    events = []
    researcher = AutoResearcher(
        _llm=FakePlanner(plan),
        _searcher=improving_search,
        max_subagents=3,
        max_critic_loops=2,
    )
    result = await researcher.arun(
        "Find evidence",
        output=tmp_path / "revised.docx",
        _event_sink=events.append,
    )

    verdicts = [event.critique.verdict for event in events if isinstance(event, CriticVerdict)]
    assert verdicts == ["revise", "pass"]
    assert calls == 2
    assert any(task.id.startswith("gap-original") for task in result.plan.tasks)
    assert result.sources[0].id == "S1"


async def test_failing_worker_does_not_abort_successful_sibling(tmp_path) -> None:
    plan = ResearchPlan(
        goal="Resilient run",
        todo_list=["Run both tasks"],
        tasks=[
            Task(id="good", title="Good", query="good"),
            Task(id="bad", title="Bad", query="bad"),
        ],
    )

    async def partial_search(query: str, **_kwargs: object) -> SearchResponse:
        if query == "bad":
            raise RuntimeError("provider unavailable")
        return SearchResponse(
            provider="fake",
            results=[
                SearchResult(
                    title="Good source",
                    url="https://example.com/good",
                    snippet="Usable evidence.",
                )
            ],
        )

    result = await AutoResearcher(
        _llm=FakePlanner(plan),
        _searcher=partial_search,
        max_critic_loops=0,
    ).arun("Resilient research", output=tmp_path / "resilient.docx")

    assert result.docx_path.exists()
    assert len(result.sources) == 1
    assert any("Task 'bad' failed (RuntimeError)" in warning for warning in result.warnings)


async def test_reported_token_budget_skips_optional_llm_criticism(tmp_path) -> None:
    plan = ResearchPlan(
        goal="Budgeted run",
        todo_list=["Find one source"],
        tasks=[Task(id="one", title="One", query="one")],
    )

    class Raw:
        def __init__(self) -> None:
            self.usage_metadata = {"total_tokens": 1_200}
            self.response_metadata = {}

    class Structured:
        async def ainvoke(self, _prompt: str):
            return {"parsed": plan, "raw": Raw()}

    class UsagePlanner:
        def with_structured_output(self, _schema, *, include_raw=False):
            assert include_raw
            return Structured()

    async def search(query: str, **_kwargs: object) -> SearchResponse:
        return SearchResponse(
            provider="fake",
            results=[
                SearchResult(
                    title=query,
                    url="https://example.com/one",
                    snippet="One fact.",
                )
            ],
        )

    result = await AutoResearcher(
        _llm=UsagePlanner(),
        _searcher=search,
        token_budget=1_000,
    ).arun("Budgeted research", output=tmp_path / "budgeted.docx")

    assert result.token_usage == {"planner": 1_200}
    assert "Token budget reached; used deterministic critic checks." in result.warnings
