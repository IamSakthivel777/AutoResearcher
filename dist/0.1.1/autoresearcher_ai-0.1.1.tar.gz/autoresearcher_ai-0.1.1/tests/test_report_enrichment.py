from __future__ import annotations

import base64
from pathlib import Path
from typing import Any

from autoresearcher.graph.synthesizer import (
    ImageQueryPlan,
    TranslationEntry,
    TranslationPack,
    add_multilingual_guides,
    add_report_images,
    plan_report_images,
)
from autoresearcher.models import ReportImageQuery, Source
from autoresearcher.report.schema import (
    ImageGalleryBlock,
    ParagraphBlock,
    ReportSpec,
    Section,
)
from autoresearcher.tools.images import ImageResult

_TINY_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8"
    "/x8AAusB9Y9ZcN0AAAAASUVORK5CYII="
)


def _report() -> ReportSpec:
    return ReportSpec(
        title="Chennai trip",
        sections=[
            Section(
                title="Weather & best time to visit",
                blocks=[
                    ParagraphBlock(
                        text="The cited forecast expects warm conditions.",
                        source_ids=["S1"],
                    )
                ],
            )
        ],
        sources=[
            Source(
                id="S1",
                url="https://example.com/weather",
                title="Weather source",
                snippet="Warm conditions",
            )
        ],
    )


async def test_multilingual_guides_preserve_citations() -> None:
    translations = {
        "tamil": "வெப்பமான வானிலை எதிர்பார்க்கப்படுகிறது.",
        "hindi": "गर्म मौसम की उम्मीद है।",
        "telugu": "వెచ్చని వాతావరణం ఉండవచ్చు.",
        "malayalam": "ചൂടുള്ള കാലാവസ്ഥ പ്രതീക്ഷിക്കുന്നു.",
    }

    class StructuredWriter:
        async def ainvoke(self, _prompt: str) -> TranslationPack:
            return TranslationPack(
                entries=[TranslationEntry(index=0, **translations)]
            )

    class Writer:
        def with_structured_output(
            self, schema: type[Any], *, include_raw: bool = False
        ) -> StructuredWriter:
            assert schema is TranslationPack
            assert include_raw
            return StructuredWriter()

    enriched = await add_multilingual_guides(
        _report(),
        ("tamil", "hindi", "telugu", "malayalam"),
        Writer(),
    )

    assert len(enriched.sections) == 5
    assert [section.title for section in enriched.sections[-4:]] == [
        "விரைவு வழிகாட்டி — தமிழ் (Tamil)",
        "त्वरित मार्गदर्शिका — हिन्दी (Hindi)",
        "త్వరిత మార్గదర్శిని — తెలుగు (Telugu)",
        "ദ്രുത ഗൈഡ് — മലയാളം (Malayalam)",
    ]
    for section in enriched.sections[-4:]:
        paragraph = section.blocks[1]
        assert isinstance(paragraph, ParagraphBlock)
        assert paragraph.source_ids == ["S1"]


async def test_report_images_include_license_and_place_second_image(
    tmp_path, monkeypatch
) -> None:
    images = [
        ImageResult(
            title=f"Chennai {index}.png",
            page_url=f"https://commons.wikimedia.org/wiki/File:Chennai_{index}.png",
            image_url=f"https://upload.wikimedia.org/chennai-{index}.png",
            thumbnail_url=f"https://upload.wikimedia.org/chennai-{index}.png",
            license="CC BY-SA 4.0",
            artist=f"Photographer {index}",
            description=f"Chennai view {index}",
        )
        for index in (1, 2)
    ]

    async def fake_search(_query: str, *, limit: int) -> list[ImageResult]:
        assert limit == 4
        return images

    async def fake_download(url: str, output: Path) -> Path:
        assert url.startswith("https://upload.wikimedia.org/")
        output.write_bytes(_TINY_PNG)
        return output

    monkeypatch.setattr("autoresearcher.graph.synthesizer.search_images", fake_search)
    monkeypatch.setattr("autoresearcher.graph.synthesizer.download_image", fake_download)

    enriched, warnings = await add_report_images(
        _report(),
        queries=[
            ReportImageQuery(area_name="Marina Beach", query="Marina Beach Chennai"),
            ReportImageQuery(
                area_name="Kapaleeshwarar Temple",
                query="Kapaleeshwarar Temple Chennai",
            ),
        ],
        asset_directory=tmp_path,
        limit=2,
    )

    assert warnings == []
    assert enriched.cover_image is not None
    assert len(enriched.sources) == 3
    assert enriched.sources[-1].snippet == "CC BY-SA 4.0; creator: Photographer 2"
    assert enriched.cover_image.area_name == "Marina Beach"
    gallery = enriched.sections[1].blocks[0]
    assert isinstance(gallery, ImageGalleryBlock)
    assert gallery.images[0].area_name == "Kapaleeshwarar Temple"
    ReportSpec.model_validate(enriched.model_dump())


async def test_image_agent_plans_named_area_queries() -> None:
    class StructuredWriter:
        async def ainvoke(self, prompt: str) -> ImageQueryPlan:
            assert "exactly 2" in prompt
            return ImageQueryPlan(
                items=[
                    ReportImageQuery(
                        area_name="Marina Beach",
                        query="Marina Beach Chennai",
                    ),
                    ReportImageQuery(
                        area_name="Government Museum",
                        query="Government Museum Chennai",
                    ),
                ]
            )

    class Writer:
        def with_structured_output(
            self, schema: type[Any], *, include_raw: bool = False
        ) -> StructuredWriter:
            assert schema is ImageQueryPlan
            assert include_raw
            return StructuredWriter()

    queries = await plan_report_images(
        _report(), location="Chennai", limit=2, llm=Writer()
    )

    assert [query.area_name for query in queries] == [
        "Marina Beach",
        "Government Museum",
    ]
