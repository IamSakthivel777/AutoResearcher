from __future__ import annotations

import pytest
from pydantic import ValidationError

from autoresearcher.graph.state import dedupe_sources, merge_token_usage
from autoresearcher.models import Claim, Source
from autoresearcher.report.schema import ParagraphBlock, ReportSpec, Section


def test_claim_requires_a_source() -> None:
    with pytest.raises(ValidationError):
        Claim(text="An unsupported fact", source_ids=[])


def test_factual_report_block_requires_a_source() -> None:
    with pytest.raises(ValidationError, match="require at least one source_id"):
        ParagraphBlock(text="An unsupported fact")


def test_report_rejects_unknown_source_reference() -> None:
    with pytest.raises(ValidationError, match="unknown source ids"):
        ReportSpec(
            title="Invalid report",
            sections=[
                Section(
                    title="Finding",
                    blocks=[ParagraphBlock(text="A fact", source_ids=["S2"])],
                )
            ],
            sources=[Source(id="S1", url="https://example.com", title="Example")],
        )


def test_source_reducer_deduplicates_normalized_urls() -> None:
    first = Source(id="S1", url="https://example.com/page/", title="First")
    duplicate = Source(id="S2", url="https://example.com/page", title="Duplicate")

    assert dedupe_sources([first], [duplicate]) == [first]


def test_token_usage_reducer_sums_parallel_roles() -> None:
    assert merge_token_usage(
        {"planner": 10, "worker": 2},
        {"worker": 3, "critic": 4},
    ) == {"planner": 10, "worker": 5, "critic": 4}
