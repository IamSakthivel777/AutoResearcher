from __future__ import annotations

from docx import Document

from autoresearcher import AutoResearcher, PlanCreated, ReportWritten
from autoresearcher.tools.search import SearchResponse, SearchResult


async def fake_search(query: str, **_kwargs: object) -> SearchResponse:
    slug = "sights" if "sights" in query else "transport"
    return SearchResponse(
        provider="fake",
        results=[
            SearchResult(
                title=f"Official {slug} guide",
                url=f"https://example.com/{slug}",
                snippet=f"Verified information about Chennai {slug}.",
                score=0.9,
            )
        ],
    )


async def test_full_offline_async_run_produces_cited_docx(tmp_path, fake_planner) -> None:
    output = tmp_path / "chennai.docx"
    researcher = AutoResearcher(_llm=fake_planner, _searcher=fake_search)

    result = await researcher.arun("Chennai trip for 3 days", output=output)

    assert result.docx_path == output.resolve()
    assert len(result.sources) == 2
    factual_blocks = [
        block
        for section in result.report_spec.sections
        for block in section.blocks
        if getattr(block, "factual", False)
    ]
    assert all(block.source_ids for block in factual_blocks)
    reopened = Document(output)
    assert any(paragraph.text == "Sources" for paragraph in reopened.paragraphs)


def test_stream_yields_typed_events(tmp_path, fake_planner) -> None:
    researcher = AutoResearcher(_llm=fake_planner, _searcher=fake_search)

    events = list(researcher.stream("Chennai trip for 3 days", output=tmp_path / "stream.docx"))

    assert isinstance(events[0], PlanCreated)
    assert isinstance(events[-1], ReportWritten)
    assert events[-1].path.endswith("stream.docx")
