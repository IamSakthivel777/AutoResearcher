from __future__ import annotations

import httpx
import respx

from autoresearcher.tools import search


@respx.mock
async def test_tavily_search_is_typed_and_does_not_return_key() -> None:
    route = respx.post("https://api.tavily.com/search").mock(
        return_value=httpx.Response(
            200,
            json={
                "results": [
                    {
                        "title": "Official guide",
                        "url": "https://example.com/guide",
                        "content": "A concise source-backed summary.",
                        "score": 0.9,
                    }
                ]
            },
        )
    )

    response = await search.web_search("a useful query", api_key="private-tavily-key")

    assert route.called
    assert response.provider == "tavily"
    assert response.results[0].title == "Official guide"
    assert "private-tavily-key" not in response.model_dump_json()


@respx.mock
async def test_tavily_failure_uses_duckduckgo(monkeypatch) -> None:
    respx.post("https://api.tavily.com/search").mock(return_value=httpx.Response(503))
    monkeypatch.setattr(
        search,
        "_duckduckgo_search",
        lambda _inputs: [
            search.SearchResult(
                title="Fallback",
                url="https://example.org/fallback",
                snippet="Fallback snippet",
            )
        ],
    )

    response = await search.web_search("a useful query", api_key="invalid")

    assert response.provider == "duckduckgo"
    assert response.warning == "Tavily search failed (HTTPStatusError); used DuckDuckGo fallback."
