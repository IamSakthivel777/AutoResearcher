from __future__ import annotations

from datetime import date

import httpx
import pytest
import respx

from autoresearcher.errors import ToolError
from autoresearcher.tools.calculations import (
    GeoPoint,
    estimate_budget,
    estimate_travel_time,
)
from autoresearcher.tools.images import download_image, search_images
from autoresearcher.tools.itinerary import ItineraryPlace, build_itinerary
from autoresearcher.tools.memory import embed_and_store, retrieve_similar
from autoresearcher.tools.places import search_places
from autoresearcher.tools.weather import get_weather_forecast
from autoresearcher.tools.web import fetch_page


@respx.mock
async def test_fetch_page_extracts_visible_text() -> None:
    respx.get("https://example.com/guide").mock(
        return_value=httpx.Response(
            200,
            headers={"content-type": "text/html; charset=utf-8"},
            text=(
                "<html><head><title>Guide</title><style>hidden</style></head>"
                "<body><h1>Chennai</h1><script>ignored()</script><p>Useful text.</p></body>"
                "</html>"
            ),
        )
    )

    page = await fetch_page("https://example.com/guide")

    assert page.title == "Guide"
    assert "Useful text." in page.text
    assert "ignored" not in page.text


async def test_fetch_page_rejects_private_networks() -> None:
    with pytest.raises(ToolError, match="private"):
        await fetch_page("http://127.0.0.1/admin")


@respx.mock
async def test_search_places_preserves_osm_provenance() -> None:
    respx.get("https://nominatim.openstreetmap.org/search").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "osm_type": "node",
                    "osm_id": 123,
                    "name": "Museum",
                    "display_name": "Museum, Chennai",
                    "lat": "13.06",
                    "lon": "80.25",
                    "type": "museum",
                    "extratags": {"opening_hours": "Mo-Sa 09:00-17:00"},
                }
            ],
        )
    )

    places = await search_places("museum", near="Chennai")

    assert places[0].name == "Museum"
    assert str(places[0].source_url) == "https://www.openstreetmap.org/node/123"
    assert places[0].opening_hours == "Mo-Sa 09:00-17:00"


@respx.mock
async def test_weather_forecast_uses_open_meteo() -> None:
    respx.get("https://geocoding-api.open-meteo.com/v1/search").mock(
        return_value=httpx.Response(
            200,
            json={"results": [{"name": "Chennai", "latitude": 13.08, "longitude": 80.27}]},
        )
    )
    respx.get("https://api.open-meteo.com/v1/forecast").mock(
        return_value=httpx.Response(
            200,
            json={
                "latitude": 13.08,
                "longitude": 80.27,
                "timezone": "Asia/Kolkata",
                "daily": {
                    "time": ["2026-09-29"],
                    "temperature_2m_min": [25.0],
                    "temperature_2m_max": [33.0],
                    "precipitation_probability_max": [40],
                    "weather_code": [61],
                },
            },
        )
    )

    forecast = await get_weather_forecast(
        "Chennai", days=1, start_date=date(2026, 9, 29)
    )

    assert forecast.location == "Chennai"
    assert forecast.days[0].temperature_max_c == 33
    assert str(forecast.source_url).startswith("https://api.open-meteo.com/v1/forecast")
    assert "start_date=2026-09-29" in str(forecast.source_url)


@respx.mock
async def test_commons_image_search_filters_license_and_downloads(tmp_path) -> None:
    respx.get("https://commons.wikimedia.org/w/api.php").mock(
        return_value=httpx.Response(
            200,
            json={
                "query": {
                    "pages": [
                        {
                            "title": "File:Chennai.jpg",
                            "canonicalurl": "https://commons.wikimedia.org/wiki/File:Chennai.jpg",
                            "imageinfo": [
                                {
                                    "mime": "image/jpeg",
                                    "url": "https://upload.wikimedia.org/chennai-full.jpg",
                                    "thumburl": "https://thumb.wikimedia.org/chennai.jpg",
                                    "extmetadata": {
                                        "LicenseShortName": {"value": "CC BY-SA 4.0"},
                                        "Artist": {"value": "Example photographer"},
                                        "ImageDescription": {
                                            "value": "<b>Chennai landmark</b>"
                                        },
                                    },
                                }
                            ],
                        },
                        {
                            "title": "File:Restricted.jpg",
                            "canonicalurl": (
                                "https://commons.wikimedia.org/wiki/File:Restricted.jpg"
                            ),
                            "imageinfo": [
                                {
                                    "mime": "image/jpeg",
                                    "url": "https://upload.wikimedia.org/restricted.jpg",
                                    "extmetadata": {
                                        "LicenseShortName": {"value": "All rights reserved"}
                                    },
                                }
                            ],
                        },
                    ]
                }
            },
        )
    )
    respx.get("https://thumb.wikimedia.org/chennai.jpg").mock(
        return_value=httpx.Response(
            200,
            content=b"jpeg bytes",
            headers={"content-type": "image/jpeg"},
        )
    )

    images = await search_images("Chennai landmark", limit=2)
    path = await download_image(str(images[0].thumbnail_url), tmp_path / "chennai.jpg")

    assert len(images) == 1
    assert images[0].license == "CC BY-SA 4.0"
    assert images[0].artist == "Example photographer"
    assert images[0].description == "Chennai landmark"
    assert path.read_bytes() == b"jpeg bytes"


def test_estimation_tools_are_deterministic_and_explicit() -> None:
    travel = estimate_travel_time(
        GeoPoint(latitude=13.06, longitude=80.25),
        GeoPoint(latitude=13.08, longitude=80.27),
        mode="drive",
    )
    budget = estimate_budget(
        3,
        travelers=2,
        accommodation_per_night=100,
        meals_per_person_day=20,
        contingency_percent=10,
    )

    assert 0 < travel.distance_km < 5
    assert travel.is_estimate
    assert budget.total == 352
    assert budget.per_person == 176


def test_local_memory_retrieves_similar_source_backed_text() -> None:
    namespace = "phase2-test"
    ids = embed_and_store(
        ["Chennai has urban beaches", "Mountain equipment checklist"],
        metadata=[
            {"title": "City guide", "source_url": "https://example.com/chennai"},
            {"source_url": "https://example.com/mountains"},
        ],
        namespace=namespace,
    )

    results = retrieve_similar("Chennai beaches", namespace=namespace, k=1)

    assert len(ids) == 2
    assert results[0].id == ids[0]
    assert str(results[0].source_url) == "https://example.com/chennai"


def test_itinerary_clusters_nearby_places_and_respects_open_days() -> None:
    places = [
        ItineraryPlace(name="A1", latitude=10, longitude=10),
        ItineraryPlace(name="B1", latitude=20, longitude=20),
        ItineraryPlace(name="A2", latitude=10, longitude=10.01),
        ItineraryPlace(name="B2", latitude=20, longitude=20.01, open_days=[2]),
    ]

    itinerary = build_itinerary(places, 2, start_date=date(2026, 9, 28))

    day_one = {place.name for place in itinerary.days[0].places}
    day_two = {place.name for place in itinerary.days[1].places}
    assert day_one == {"A1", "A2"}
    assert day_two == {"B1", "B2"}
