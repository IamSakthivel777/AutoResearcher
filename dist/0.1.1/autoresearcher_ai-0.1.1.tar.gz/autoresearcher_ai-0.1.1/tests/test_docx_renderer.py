from __future__ import annotations

import base64
from zipfile import ZipFile

from docx import Document

from autoresearcher.models import Source
from autoresearcher.report.docx_renderer import DocxRenderer
from autoresearcher.report.schema import (
    ImageBlock,
    ImageGalleryBlock,
    ParagraphBlock,
    ReportSpec,
    Section,
)

_TINY_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8"
    "/x8AAusB9Y9ZcN0AAAAASUVORK5CYII="
)


def test_renderer_creates_openable_docx_with_toc_and_sources(tmp_path) -> None:
    source = Source(
        id="S1",
        url="https://example.com/guide",
        title="Example guide",
        snippet="Supported information",
    )
    spec = ReportSpec(
        title="Test report",
        subtitle="A deterministic document",
        assumptions=["This is a test assumption."],
        sections=[
            Section(
                title="Findings",
                blocks=[ParagraphBlock(text="Supported information", source_ids=["S1"])],
            )
        ],
        sources=[source],
    )
    output = tmp_path / "nested" / "report.docx"

    path = DocxRenderer().render(spec, output)
    reopened = Document(path)
    text = "\n".join(paragraph.text for paragraph in reopened.paragraphs)

    assert path == output.resolve()
    assert "Test report" in text
    assert f"Prepared on {spec.report_date.strftime('%d %B %Y')}" in text
    assert "Findings" in text
    assert "Sources" in text
    assert "[1] Example guide" in text
    with ZipFile(path) as archive:
        document_xml = archive.read("word/document.xml")
        relationships_xml = archive.read("word/_rels/document.xml.rels")
    assert b'TOC \\o "1-3"' in document_xml
    assert b"https://example.com/guide" in relationships_xml


def test_renderer_embeds_cover_and_sets_indic_font(tmp_path) -> None:
    image_path = tmp_path / "cover.png"
    image_path.write_bytes(_TINY_PNG)
    image_source = Source(
        id="S1",
        url="https://commons.wikimedia.org/wiki/File:Chennai.png",
        title="Image: Chennai",
        snippet="CC BY-SA 4.0; creator: Example",
    )
    fact_source = Source(
        id="S2",
        url="https://example.com/tamil",
        title="Tamil guide",
        snippet="Supported information",
    )
    spec = ReportSpec(
        title="Chennai guide",
        cover_image=ImageBlock(
            path=str(image_path),
            caption="Chennai landmark — CC BY-SA 4.0; creator: Example",
            source_ids=["S1"],
        ),
        sections=[
            Section(
                title="விரைவு வழிகாட்டி — தமிழ் (Tamil)",
                blocks=[
                    ParagraphBlock(
                        text="சென்னைக்கான பயண வழிகாட்டி.",
                        source_ids=["S2"],
                    ),
                    ImageGalleryBlock(
                        images=[
                            ImageBlock(
                                path=str(image_path),
                                area_name="Marina Beach",
                                caption="Licensed Chennai view",
                                source_ids=["S1"],
                            ),
                            ImageBlock(
                                path=str(image_path),
                                area_name="Mylapore",
                                caption="Licensed Chennai view",
                                source_ids=["S1"],
                            ),
                        ]
                    ),
                ],
            )
        ],
        sources=[image_source, fact_source],
    )

    path = DocxRenderer().render(spec, tmp_path / "multilingual.docx")
    reopened = Document(path)

    assert len(reopened.inline_shapes) == 3
    with ZipFile(path) as archive:
        document_xml = archive.read("word/document.xml")
    assert b"Nirmala UI" in document_xml
    assert "CC BY-SA 4.0; creator: Example" in "\n".join(
        paragraph.text for paragraph in reopened.paragraphs
    )
