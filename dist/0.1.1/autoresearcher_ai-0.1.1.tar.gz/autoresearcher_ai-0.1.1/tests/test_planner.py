from __future__ import annotations

from conftest import FakePlanner

from autoresearcher.graph.clarifier import clarify_question
from autoresearcher.graph.planner import (
    create_plan,
    ensure_trip_essentials,
    prepare_structured_model,
)
from autoresearcher.models import ResearchPlan, Task


async def test_planner_repairs_invalid_structured_output_once(research_plan) -> None:
    planner = FakePlanner([{"goal": "missing required fields"}, research_plan])

    result = await create_plan("Chennai trip for 3 days", planner)

    assert result == research_plan
    assert planner.structured.calls == 2


async def test_planner_tracks_reported_token_usage(research_plan) -> None:
    class Raw:
        def __init__(self) -> None:
            self.usage_metadata = {"total_tokens": 123}
            self.response_metadata = {}

    class Structured:
        async def ainvoke(self, _prompt: str):
            return {"parsed": research_plan, "raw": Raw()}

    class Planner:
        def with_structured_output(self, _schema, *, include_raw=False):
            assert include_raw
            return Structured()

    usage: list[int] = []

    result = await create_plan("Chennai trip", Planner(), usage_sink=usage.append)

    assert result == research_plan
    assert usage == [123]


def test_trip_clarification_and_plan_use_destination_for_weather() -> None:
    clarification = clarify_question("Chennai trip for 3 days")
    plan = ResearchPlan(
        goal="Plan a Chennai trip",
        template="trip",
        todo_list=["Build an itinerary"],
        tasks=[
            Task(
                id="forecast",
                title="Weather",
                worker_type="weather",
                query="Chennai trip for 3 days weather",
            )
        ],
    )

    enhanced = ensure_trip_essentials(plan, clarification)

    assert clarification.location == "Chennai"
    assert clarification.days == 3
    assert clarification.start_date is None
    assert any("No travel date" in item for item in clarification.assumptions)
    assert enhanced.tasks[0].worker_type == "weather"
    assert enhanced.tasks[0].query == "Chennai"
    assert enhanced.tasks[1].title == "Best time to visit Chennai"
    assert enhanced.tasks[1].worker_type == "web"


def test_clarifier_uses_only_an_explicit_complete_travel_date() -> None:
    explicit = clarify_question("Chennai trip for 3 days from 10 December 2026")
    missing_year = clarify_question("Chennai trip for 3 days from December 10")

    assert explicit.start_date.isoformat() == "2026-12-10"
    assert missing_year.start_date is None


def test_openai_structured_models_use_function_calling(research_plan) -> None:
    received: dict[str, object] = {}

    class OpenAIPlanner:
        def with_structured_output(self, schema, **kwargs):
            received.update(kwargs)
            return object()

    OpenAIPlanner.__module__ = "langchain_openai.fake"

    prepare_structured_model(OpenAIPlanner(), type(research_plan))

    assert received == {"include_raw": True, "method": "function_calling"}
